function [A1, A2, A3] = create_AdeeptArm_A_matrices(jointAngles)
% Create the A matrices for the arm.

% A1 = create_A_matrix(___, ___, ___, jointAngles(1));
% A2 = create_A_matrix(___, ___, ___, jointAngles(2));
% A3 = create_A_matrix(___, ___, ___, jointAngles(3));

end