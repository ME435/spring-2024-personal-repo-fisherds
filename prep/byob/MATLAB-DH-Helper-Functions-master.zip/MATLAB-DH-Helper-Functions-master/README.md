Staring code creating a DH arm simulator.<br>
<br>
Starting code includes patch objects and some scaffolding for GUIDE.