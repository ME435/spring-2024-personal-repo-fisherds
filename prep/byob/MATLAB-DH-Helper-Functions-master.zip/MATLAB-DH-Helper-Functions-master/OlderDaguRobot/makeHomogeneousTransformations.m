function [A1, A2, A3, A4, A5] = makeHomogeneousTransformations(degreesTheta1, degreesTheta2, degreesTheta3, degreesTheta4, degreesTheta5)
%MAKEHOMOGENEOUSTRANSFORMATIONS Create the DH matrices for the arm.

% A1 = homogeneousTransformation(___, ___, ___, degreesTheta1);
% A2 = homogeneousTransformation(___, ___, ___, degreesTheta2);
% A3 = homogeneousTransformation(___, ___, ___, degreesTheta3);
% A4 = homogeneousTransformation(___, ___, ___, degreesTheta4);
% A5 = homogeneousTransformation(___, ___, ___, degreesTheta5);

end
